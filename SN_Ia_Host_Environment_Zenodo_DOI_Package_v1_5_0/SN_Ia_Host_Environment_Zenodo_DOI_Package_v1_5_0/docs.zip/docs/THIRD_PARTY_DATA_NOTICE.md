# Third-party data notice

The processed and derived tables in this archive originate from public ZTF
DR2, Pantheon+, and DES-SN5YR products. Users must cite the corresponding
survey and data-release publications when reusing these data.

The CC BY 4.0 licence in this archive applies to the authors' derived tables,
figures, metadata, and documentation to the extent permitted by the licences
and attribution requirements of the underlying products. It does not replace
or override the original data providers' terms.
