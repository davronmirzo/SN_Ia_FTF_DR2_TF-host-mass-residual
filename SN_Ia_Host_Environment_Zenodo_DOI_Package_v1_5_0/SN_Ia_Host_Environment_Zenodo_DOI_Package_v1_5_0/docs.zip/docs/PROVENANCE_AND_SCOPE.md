# Provenance and scope

This release starts from processed object-level survey products:

- a validated 2642-object ZTF DR2 residual layer;
- a 559-object Pantheon+ comparison layer;
- a corrected 1829-object DES-SN5YR Hubble-diagram layer;
- a deduplicated ZTF raw-to-final selection-training layer.

The archive contains the downstream statistical audits and their
machine-readable outputs. It does not reconstruct upstream cadence,
detection, targeting, classification, host-association, survey ingestion, or
collaboration-level bias-correction pipelines.

The ZTF residual layer was identified from upstream pipeline provenance and
then checked by reproducing the reference global host-mass coefficient.
Alternative diagnostic residual layers are retained only for response-layer
validation.

Pantheon+ and DES-SN5YR permit product-level host-mass and tomography
estimation. They do not provide the raw parent-to-final inclusion structure
or directly equivalent local-environment fields required for the complete
ZTF selection-forward and environmental protocol. The release therefore
includes every externally identifiable reduced audit while preserving the
distinction between coefficient estimation and selection-process
reconstruction.
