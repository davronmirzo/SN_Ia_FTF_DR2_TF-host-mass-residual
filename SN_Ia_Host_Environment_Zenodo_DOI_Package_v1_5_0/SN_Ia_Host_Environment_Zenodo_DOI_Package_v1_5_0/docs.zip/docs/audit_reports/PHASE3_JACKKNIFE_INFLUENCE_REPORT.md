# Phase-3 object-level jackknife and influence audit

## Input validation

- Rows: 2642
- Frozen global mass step: -0.0751448029
- Frozen standard error: 0.0084867679
- Five-bin slope: +1.5026551707
- Five-bin heterogeneity Q: 10.6136541956

## Main leave-one-out results

- Global step range:
  [-0.0762224388,
   -0.0736170459] mag.
- Largest absolute global-step shift:
  0.0015277570 mag.
- Tomographic-slope range:
  [+1.3456594415,
   +1.5703016430].
- All leave-one-out slopes are positive.
- Tomographic-slope p-value range:
  [0.007002,
   0.020675].
- Heterogeneity-Q range:
  [8.464365,
   11.687675].
- Heterogeneity p-value range:
  [0.019831,
   0.075975].

## Most consequential deletion

Deleting `2018cxk` at z =
0.028904 changes Q to
8.464365
(p = 0.075975).
The slope remains
+1.345659
(p = 0.007002).

## Interpretation

The global host-mass detection and the sign of the five-bin slope are not
controlled by any single observation. The formal Q-test threshold is more
fragile: one low-redshift high-residual observation can move its p-value above
0.05. The manuscript should therefore retain the current combined-evidence
framing and should not use the Q-test alone as the basis for the
non-stationarity claim.
