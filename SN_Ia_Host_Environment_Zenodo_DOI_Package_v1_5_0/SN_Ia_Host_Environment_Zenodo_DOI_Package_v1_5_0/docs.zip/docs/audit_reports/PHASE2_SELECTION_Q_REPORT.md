# Phase-2 selection-stress audit for heterogeneity Q

## Validated observed target

- Five-bin heterogeneity: Q = 10.613654
- Chi-square probability: p = 0.031267
- Degrees of freedom: 4

## Forward-simulation results

| Input | Median Q | 16--84% | 2.5--97.5% | Fraction Q >= observed | Leading-one p |
|---|---:|---:|---:|---:|---:|
| Zero effect | 3.9262 | [1.6016, 7.1587] | [0.6469, 12.0017] | 13/300 | 0.0465 |
| Constant step | 4.1737 | [1.6155, 7.8879] | [0.5324, 11.9671] | 12/300 | 0.0432 |
| Observed tomography | 12.7906 | [7.7615, 21.8018] | [3.9270, 31.6854] | 192/300 | 0.6412 |

## Interpretation

The observed heterogeneity lies near the upper tail of the zero-effect and
constant-step selection-forward distributions. It is routinely recovered when
the observed tomographic structure is injected. The result strengthens the
selection-stress argument, but the probabilities are close to 0.05 and are
based on 300 simulations per input. The manuscript should therefore use
“uncommon under the tested forward models” rather than “ruled out”.

## Phase-1 output note

The uploaded Phase-1 output is numerically usable. Missing fractions are low
(about 0--2.5 per cent), but several missingness screens have AUC values above
0.65. Availability is therefore low-loss but not demonstrably missing
completely at random. Keep this audit in the Appendix and avoid claiming that
the proxy-complete subset is unbiased.

The uploaded `phase1_results_addendum.tex` contains corrupted LaTeX control
sequences around the mass threshold and sigma notation. A corrected version is
included in `phase1_corrections/phase1_results_addendum_corrected.tex`.
