# Zenodo deposition checklist

1. Extract the archive and run `python checks/verify_release.py`.
2. Confirm that the title, version `1.5.0`, release date `2026-07-22`, and three
   creator names match the Zenodo draft record.
3. Reserve the DOI in Zenodo.
4. Run `python checks/set_reserved_doi.py 10.5281/zenodo.XXXXXXX`.
5. Rerun `python checks/verify_release.py` and confirm PASS with no DOI warning.
6. Re-create the ZIP from the updated top-level directory without adding
   manuscript or journal-build files.
7. Use the description and keywords in `metadata/zenodo_metadata.json`.
8. Confirm the mixed licensing note: code is MIT; derived content is CC BY 4.0
   subject to upstream data terms.
9. Upload only the final ZIP and publish the Zenodo record.
