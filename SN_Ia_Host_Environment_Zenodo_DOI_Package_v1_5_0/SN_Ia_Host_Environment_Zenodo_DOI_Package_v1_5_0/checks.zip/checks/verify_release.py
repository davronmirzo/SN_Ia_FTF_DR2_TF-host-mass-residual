#!/usr/bin/env python
from __future__ import annotations
from pathlib import Path
import hashlib, json, math, re, sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
 return h.hexdigest()
def close(v,t,tol):
 if not math.isfinite(float(v)) or abs(float(v)-t)>tol: raise AssertionError(f'{v} differs from {t}')
required=['README.md','RUNBOOK.md','RELEASE_NOTES.md','CITATION.cff','codemeta.json','environment.yml','requirements.txt',
'data/processed/ZTF_DR2_validated_residual_layer.csv','data/processed/empirical_selection_training_sample.csv','data/processed/PantheonPlus_analysis_sample.csv','data/processed/DES_SN5YR_analysis_sample.csv',
'code/71_selection_stress_heterogeneity_Q.py','code/73_object_level_jackknife_influence.py','code/74_environment_stratification_interaction.py','code/75_external_product_common_support_influence.py','code/76_statistical_calibration_audit.py','code/make_fig01_correction_validity_workflow.py','code/make_fig01_correction_validity_workflow.m',
'figures/fig01_analysis_flow.pdf','metadata/key_results.csv','metadata/audit_inventory.csv','metadata/workflow_source_mapping.csv','metadata/residual_layer_provenance.csv','metadata/table_index.csv','metadata/figure_index.csv','metadata/file_manifest_sha256.csv']
for rel in required:
 if not (ROOT/rel).exists(): raise AssertionError(f'Missing required file: {rel}')
# No manuscript/build products or non-PDF figure duplicates.
for p in ROOT.rglob('*'):
 if not p.is_file(): continue
 rel=p.relative_to(ROOT).as_posix(); low=rel.lower()
 if p.suffix.lower() in {'.tex','.bbl','.aux','.log','.png','.eps','.pyc'}: raise AssertionError(f'Forbidden release format: {rel}')
 if '__pycache__' in p.parts: raise AssertionError(f'Python cache artefact present: {rel}')
 if 'manuscript' in low or low.startswith('sn_paper'): raise AssertionError(f'Manuscript artefact present: {rel}')
for p in (ROOT/'figures').iterdir():
 if p.is_file() and p.suffix.lower()!='.pdf': raise AssertionError(f'Non-PDF figure: {p.name}')
# Tables and JSON are parseable.
for p in ROOT.rglob('*.csv'):
 try: pd.read_csv(p)
 except Exception as e: raise AssertionError(f'Unreadable CSV {p.relative_to(ROOT)}: {e}')
for p in ROOT.rglob('*.json'):
 try: json.loads(p.read_text(encoding='utf-8'))
 except Exception as e: raise AssertionError(f'Invalid JSON {p.relative_to(ROOT)}: {e}')
# Frozen row counts.
if len(pd.read_csv(ROOT/'data/processed/ZTF_DR2_validated_residual_layer.csv'))!=2642: raise AssertionError('ZTF row-count drift')
sel=pd.read_csv(ROOT/'data/processed/empirical_selection_training_sample.csv')
if len(sel)!=3483: raise AssertionError('Selection row-count drift')
if len(pd.read_csv(ROOT/'data/processed/PantheonPlus_analysis_sample.csv'))!=559: raise AssertionError('Pantheon row-count drift')
if len(pd.read_csv(ROOT/'data/processed/DES_SN5YR_analysis_sample.csv'))!=1829: raise AssertionError('DES row-count drift')
# Frozen key results.
b=pd.read_csv(ROOT/'results/tables/reconciliation60_best_binned_summary.csv').iloc[0]
close(b.slope,1.502655170668689,1e-10); close(b.heterogeneity_Q,10.613654195563075,1e-10)
c=pd.read_csv(ROOT/'results/tables/statistical_calibration_summary.csv').set_index('calibration')
close(c.loc['nominal_residual_scaled','slope_se'],0.284419583291319,1e-10)
close(c.loc['unit_scale_floor','slope_se'],0.485394124022863,1e-10)
p4=pd.read_csv(ROOT/'results/tables/phase4_global_interactions.csv')
r=p4[(p4.model=='offset_interaction_simple')&(p4.term=='H_R')].iloc[0]
close(r.coefficient,0.2341545357288053,1e-10)
# Indices cover all frozen results and figures.
ti=pd.read_csv(ROOT/'metadata/table_index.csv'); indexed=set(ti.file)
actual={p.relative_to(ROOT).as_posix() for p in (ROOT/'results/tables').iterdir() if p.is_file() and p.suffix.lower() in {'.csv','.json'}}
if indexed!=actual: raise AssertionError(f'Table index mismatch: missing={sorted(actual-indexed)} extra={sorted(indexed-actual)}')
fi=pd.read_csv(ROOT/'metadata/figure_index.csv'); findex=set(fi.file)
factual={p.relative_to(ROOT).as_posix() for p in (ROOT/'figures').iterdir() if p.is_file()}
if findex!=factual: raise AssertionError(f'Figure index mismatch: missing={sorted(factual-findex)} extra={sorted(findex-factual)}')
# No private/absolute paths or obsolete internal project labels in text release files.
for p in ROOT.rglob('*'):
 if not p.is_file() or p.suffix.lower()=='.pdf': continue
 if p.relative_to(ROOT).as_posix() in {'metadata/file_manifest_sha256.csv','docs/verification_report.txt','checks/verify_release.py'}: continue
 txt=p.read_text(encoding='utf-8',errors='ignore')
 if re.search(r'[A-Za-z]:\\\\(?:Users|ProgramData|Downloads|Desktop)\\\\',txt): raise AssertionError(f'Private absolute path in {p.relative_to(ROOT)}')
 if 'ZTF_mass_step_revision' in txt or 'snia_host_environment_release_v1_3_2' in txt: raise AssertionError(f'Obsolete internal project label in {p.relative_to(ROOT)}')
# No exact duplicate content.
groups={}
for p in ROOT.rglob('*'):
 if p.is_file() and p.relative_to(ROOT).as_posix() not in {'metadata/file_manifest_sha256.csv','docs/verification_report.txt'}:
  groups.setdefault(digest(p),[]).append(p.relative_to(ROOT).as_posix())
dups=[v for v in groups.values() if len(v)>1]
if dups: raise AssertionError(f'Duplicate file content: {dups}')
# Manifest integrity.
manifest=pd.read_csv(ROOT/'metadata/file_manifest_sha256.csv')
excluded={'metadata/file_manifest_sha256.csv','docs/verification_report.txt'}
for row in manifest.itertuples(index=False):
 p=ROOT/row.relative_path
 if not p.exists(): raise AssertionError(f'Manifest missing file: {row.relative_path}')
 if p.stat().st_size!=int(row.size_bytes) or digest(p)!=row.sha256: raise AssertionError(f'Manifest mismatch: {row.relative_path}')
current={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix() not in excluded}
listed=set(manifest.relative_path)
if current!=listed: raise AssertionError(f'Manifest membership mismatch missing={sorted(current-listed)} extra={sorted(listed-current)}')
placeholder=[]
for rel in ['README.md','CITATION.cff','codemeta.json','metadata/zenodo_metadata.json','metadata/release_summary.json']:
 if '10.5281/zenodo.TBD' in (ROOT/rel).read_text(encoding='utf-8'): placeholder.append(rel)
print('PASS: clean release structure, indices, frozen results, and SHA-256 manifest verified.')
print(f'Root: {ROOT}')
print(f'Files verified: {len(manifest)}')
if placeholder: print('WARNING: reserved DOI placeholder remains in '+', '.join(placeholder))
